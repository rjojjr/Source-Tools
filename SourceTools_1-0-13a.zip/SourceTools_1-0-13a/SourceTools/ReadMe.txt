SourceTools ReadMe

v1.0.05a

2019 Kirchner Solutions
kirchnerbusinesssolutions.com

##########################################################################

License:

You are bound by the terms defined in EULA.txt. The use of this program
means that you except the terms of the End User License Agreement(EULA)
in EULA.txt.

##########################################################################


##########################################################################

Install:

SourceTools requires that you have the latest Java Runtime Enviroment(JRE)
8 installed on the client pc. The link to the JRE installer can be
found at:

https://www.java.com/en/download/windows-64bit.jsp

You are bound by license terms provided by Oracle for the JRE.

To install SourceTools, simply place the SourceTools_VERSION folder
to the directory of your choice

If you want a desktop shortcut, right-click the LaunchTools.bat
file and select Send To --> Desktop

##########################################################################

Using SourceTools

To launch SourceTools, simply left-click the LaunchTools.bat script.

			or

Use the java -jar <source tools jar> command in terminal.

##########################################################################

Notes:

--------------------------------------------------------------------------

RSA 

RSA encryption/decryption only works on data less that 256 bytes. 
The main use of the RSA is to encrypt an AES key for a secure
handshake.

--------------------------------------------------------------------------

String Encryption

The string encryption function is meant to compliment
tools such as proguard. String encrypt is meant to be run 
before program is built. Strings are decrypted at runtime
with the implementation of our StringDecryptor API.

Best practice is to put all strings in a single class as constants,
and run string encryption. Everytime you call a string in your code
you wrap it in the decrypt method of the API.